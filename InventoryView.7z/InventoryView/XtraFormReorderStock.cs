﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace InventoryView
{
    public partial class XtraFormReorderStock : DevExpress.XtraEditors.XtraForm
    {
        public XtraFormReorderStock()
        {
            InitializeComponent();
        }
    }
}